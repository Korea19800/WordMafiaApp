package com.kj.wordmafia;

import androidx.appcompat.app.AppCompatActivity;
import android.support.v4.app.Fragment;


import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;
import androidx.viewpager.widget.ViewPager;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Tutorial04 extends AppCompatActivity {
    ViewPager vp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tutorial);

        vp = (ViewPager) findViewById(R.id.vp19800);
        Button b1 = (Button) findViewById(R.id.button1);
        Button b2 = (Button) findViewById(R.id.button2);
        Button b3 = (Button) findViewById(R.id.button3);
        Button b4 = (Button) findViewById(R.id.button4);

        vp.setAdapter(new pagerAdapter(getSupportFragmentManager()));
        vp.setCurrentItem(0);

        b1.setOnClickListener(movePageListener);
        b1.setTag(0);
        b2.setOnClickListener(movePageListener);
        b2.setTag(1);
        b3.setOnClickListener(movePageListener);
        b3.setTag(2);
        b4.setOnClickListener(movePageListener);
        b4.setTag(3);

    }

    View.OnClickListener movePageListener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            int tag = (int) view.getTag();
            vp.setCurrentItem(tag);
        }
    };

    private class pagerAdapter extends FragmentStatePagerAdapter {
        // 1. 이 부분이 다름
        public pagerAdapter(FragmentManager fm) {
            super(fm);
        }

        @Override
        // 2. 이 부분도 다름
        public  getItem(int position) {
            switch (position) {
                case 0:
                    return new Tutorial_01();
                case 1:
                    return new Tutorial_02();
                case 2:
                    return new Tutorial_03();
                case 3:
                    return new Tutorial_04();

                default:
                    return null;
            }
        }

        @Override
        public int getCount() {
            return 4;
        }

    }

}

