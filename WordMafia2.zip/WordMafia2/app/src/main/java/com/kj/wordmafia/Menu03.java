package com.kj.wordmafia;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;

public class Menu03 extends AppCompatActivity implements View.OnClickListener {
    private static MediaPlayer mp;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        mp= MediaPlayer.create(this,R.raw.menu_music);
        mp.setLooping(true);
        mp.start();

    }

    @Override
    public void onClick(View view) {
        Intent intent=new Intent(this, Tutorial04.class);
        startActivity(intent);
    }
    public void onClick2(View view) {
        Intent intent= new Intent(this, GameSetting05.class);
        startActivity(intent);
    }


    protected void onUserLeaveHint() {
        mp.pause();
        super.onUserLeaveHint();
    }
    public void onResume() {
        mp.start();
        super.onResume();
    }
    public void onDestroy() {
        mp.stop();
        super.onDestroy();
    }
    public void onBackPressed() {
        mp.stop();
        super.onBackPressed();
    }
}
